
<style> 
body 
{ 
margin:0; 
padding:0; 
background-color:#f1f1f1; 
} 
.loginbox 
{ 
width:500px; 
padding:20px; 
margin-left: 130px;
background-color:#fff; 
}
.signbox{
	text-align: center;
	margin-left: 100px;
}

</style>
 
<div class="container loginbox">
	 
<h2 style="text-align: center;">Login Using Google Account By Google OAuth Using Codeigniter </h2>
 
 <span class="signbox"><a href="<?=base_url()?>googlelogin/login"><img src="<?=base_url()?>assets/images/google-btn.png" alt=""/></a></span>

</div>